# Save into ply file:
o3d.io.write_point_cloud("output/bunny_pcd.ply", pcd)